
public class Student1 {
	static int count;
	int student_Num = ++count;
	String name;
	int kor;
	int eng;
	int math;
	int total;
	int avg;
	int rank;

}
