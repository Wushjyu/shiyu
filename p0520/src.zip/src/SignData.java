
public class SignData {
        int sign;//0-더하기;,1-빼기,2-곱하기,3-나누기
        int data1;
        int data2;
        
  //#========================
        //	Ex0520_07
        int num1;//두수 1   3
        int num2;//두수 2   5
        int result1;//8
		int result2;// -2
		int result3;
		double result4;//나누기 결과값 0
 }
