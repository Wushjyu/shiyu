

public class Data {
	int x;

}
