
public class Ex0520_10 {

	public static void main(String[] args) {
		System.out.println(5);
		System.out.println("글자출력");
		
		//오버로딩 - add() add(int a)
		//add();
		//add(int a);
		//add(String a);
		//add(int a, int b);

	}

}
