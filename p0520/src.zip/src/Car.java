
public class Car {
	
	//Car(){};
	String color;
	String gearType;
	int door;
	
//#============================================
	
	Car(String c, String g, int d){
		color = c;
		gearType = g;
		door =d;
	}
	

}
