
public class Student {
	static int count;
	int student_Num =++count;
	
	String name;
	int kor;
	int eng;
	int math;
	int total;
	double avg;
	int rank;

}
