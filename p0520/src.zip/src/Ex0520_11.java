
public class Ex0520_11 {

	public static void main(String[] args) {
		Data1 d1= new Data1();
		System.out.println(d1.value);
		Data2 d2= new Data2();
		System.out.println(d2.value);
		

	}

}//class
