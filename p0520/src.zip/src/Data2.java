
public class Data2 {
	int value;
	//생성자가 1개라도 있으면 자동으로 안만들어
	Data2(){}
	Data2(int x){//매개변수 있는 생성자
		value=x;
		
	}

}
