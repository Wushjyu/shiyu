
public class Ex0520_021 {

	public static void main(String[] args) {
		//총 4대를 더 생산
		//파랑,자동기어,5  /검정,수동기어,4 /빨강,자동기어,5 /은색,수동기어,5
		Car[] c = new Car[5];
		
		c[0] = new Car();
		c[0].color = "횐색";
		c[0].gearType = "자동기어";
		c[0].door = 4;
		c[1] = new Car();
		c[1].color = "파랑";
		c[1].gearType = "자동기어";
		c[1].door = 5;
//		System.out.println(c[0].color);

		
//#========================================		
		
//		c[0] =new Car("환색","자동기어",4);
//		c[1] =new Car("파랑","자동기어",5);
//		c[2] =new Car("검정","자동기어",4);
//		c[3] =new Car("빨강","자동기어",5);
//		c[4] =new Car("은색","자동기어",5);

		
		
		

	}

}
