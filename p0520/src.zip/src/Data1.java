
public class Data1 {
	//자동으로 기본생성자 생성됨
	//Data1(){}
	int value;

}
